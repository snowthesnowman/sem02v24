# For å interpretere Python kildekode 

```
$ python3 reverse-python.py
```