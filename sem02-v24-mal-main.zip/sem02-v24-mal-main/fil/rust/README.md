# For å kompilere rust kildekode og utføre den binære filen

```
$ rustc reverse-rust.rs
$ ./reverse-rust
```
