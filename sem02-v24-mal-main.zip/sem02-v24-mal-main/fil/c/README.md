# For å kompilere c kildekode og utføre den binære filen

```
$ gcc -o reverse reverse.c
$ ./reverse.c
```