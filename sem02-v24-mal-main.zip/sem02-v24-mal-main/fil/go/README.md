# For å kompilere Go kildekode og utføre den binære filen

```
$ go build reverse.go
$ ./reverse.go
```